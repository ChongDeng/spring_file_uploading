package com.github.lybgeek.watch.constant;

public class Constants {
    public static final String  CONFIG_NAME = "jdbc.properties";
}
