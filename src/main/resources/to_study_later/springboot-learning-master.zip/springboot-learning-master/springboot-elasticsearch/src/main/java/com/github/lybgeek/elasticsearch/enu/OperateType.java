package com.github.lybgeek.elasticsearch.enu;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum OperateType {

  ADD,UPDATE,DELETE,QUERY
}
