package com.github.lybgeek.elasticsearch.constant;

public class ElasticsearchConstant {
  public static final String SHORT_URL_INDEX = "custom_short_url";

}
