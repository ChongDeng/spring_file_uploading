package com.github.lybgeek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SliceUploadApplication
{
    public static void main( String[] args )
    {

        SpringApplication.run(SliceUploadApplication.class,args);
    }
}
