该demo主要演示springboot与百度前端组件WebUploader配合实现上传功能，本例实现功能如下：

- 1、分片上传
- 2、断点续传
- 3、秒传
- 4、oss表单上传
- 5、分片下载