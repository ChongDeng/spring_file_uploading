本例主要演示springboot动态绑定数据源进行读写分离的三种方法

> 第一种方法基于spring提供原生的AbstractRoutingDataSource进行实现

> 第二种方法使用mybatis-plus提供的dynamic-datasource-spring-boot-starter进行实现

> 第三种方法使用Sharding-JDBC进行实现





 
  