package com.github.lybgeek.modules.customerservice.constants;

public class CustomerserviceWagesConstant {

  public static final String EXCEL_TEMPLATE = "工资表模板.xls";

}
