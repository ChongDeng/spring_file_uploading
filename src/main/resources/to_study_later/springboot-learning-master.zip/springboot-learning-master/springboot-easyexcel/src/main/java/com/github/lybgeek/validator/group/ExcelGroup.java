package com.github.lybgeek.validator.group;

public interface ExcelGroup {

}
