package com.github.lybgeek.modules.image.constants;

public class ImageConstants {

  public static final String IMAGE_NAME = "名称";

  public static final String IMAGE = "图片";

  public static final String IMAGE_DESC = "描述";

  public static final String IMAGE_STATUS = "状态";

}
