本例主要演示springboot和mongodb集成，主要实现的功能点有
- mongodb 事务
- mongodb 自增ID
- mongodb 字段驼峰和mongdb属性下划线映射
- mongodb 自定义转换器实现
- mongodb 分页
- 自定义枚举校验