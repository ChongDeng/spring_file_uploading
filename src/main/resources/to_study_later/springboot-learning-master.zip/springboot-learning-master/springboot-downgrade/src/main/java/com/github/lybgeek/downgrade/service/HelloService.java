package com.github.lybgeek.downgrade.service;

public interface HelloService {

  String hello(String userName);

}
