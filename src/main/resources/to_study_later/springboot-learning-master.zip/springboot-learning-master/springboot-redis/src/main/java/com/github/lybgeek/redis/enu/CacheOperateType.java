package com.github.lybgeek.redis.enu;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CacheOperateType {
  ADD,UPDTAE,DELETE,QUERY

}
