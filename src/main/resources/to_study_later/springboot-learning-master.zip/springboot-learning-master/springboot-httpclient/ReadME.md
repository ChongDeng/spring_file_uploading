本例主要演示springboot与http客户端整合，整合的http客户端有如下

- 1、与httpclient进行整合
- 2、与restTemplate进行整合
- 3、与webClient进行整合
- 4、通过自定义注解，实现多种http客户端





> 
 
 
  