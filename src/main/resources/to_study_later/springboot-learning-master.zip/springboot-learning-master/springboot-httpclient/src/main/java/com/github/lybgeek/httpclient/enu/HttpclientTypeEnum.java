package com.github.lybgeek.httpclient.enu;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum  HttpclientTypeEnum {
    REST_TEMPLATE,WEB_CLIENT,HTTP_CLIENT;
}
