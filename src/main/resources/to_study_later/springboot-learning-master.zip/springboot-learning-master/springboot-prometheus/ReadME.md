本例主要演示springboot与Prometheus整合实现监控springboot应用同时演示自定义监控埋点，采集数据通过grafana进行展示


 
 
  