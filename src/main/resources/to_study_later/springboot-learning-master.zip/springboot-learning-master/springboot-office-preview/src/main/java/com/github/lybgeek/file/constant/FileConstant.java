package com.github.lybgeek.file.constant;

public class FileConstant {

  public static final String PREVIEW_REMOTE_URL = "http://localhost:8080/preview/convertFile";

  public static final String FILE_PARAM_KEY = "file";

  public static final String SUCCESS = "success";

}
