package com.github.lybgeek.preview.constants;

import java.util.Arrays;
import java.util.List;

public class Constants {

  public static List<String> fileType2Htmls = Arrays.asList("xls","xlsx");

}
