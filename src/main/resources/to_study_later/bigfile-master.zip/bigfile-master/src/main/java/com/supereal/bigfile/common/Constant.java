package com.supereal.bigfile.common;

import java.io.File;

/**
 * Create by tianci
 * 2019/1/11 14:22
 */
public class Constant {

    public static final String PATH = System.getProperty("user.dir") + File.separator + "file";
}
